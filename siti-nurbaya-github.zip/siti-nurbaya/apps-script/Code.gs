/**
 * SITI NURBAYA - server penyimpanan akun (Google Apps Script)
 * Program Dokter Muda IKM Puskesmas Belimbing
 *
 * Cara pakai: lihat panduan pemasangan. Singkatnya:
 * 1. Tempel kode ini di Extensions > Apps Script pada Google Sheet baru.
 * 2. Jalankan fungsi "siapkan" satu kali.
 * 3. Deploy sebagai Web app (Execute as: Me, Who has access: Anyone).
 *
 * Lembar yang dibuat:
 * - Akun       : daftar siswi yang mendaftar (nama panggilan, kelas, waktu daftar).
 * - Skrining   : hasil skrining yang disimpan siswi ke akunnya.
 * - Ringkasan  : jumlah akun dan hasil skrining, dihitung otomatis.
 * - Catatan    : catatan TTD dan haid. Isinya terenkripsi di perangkat siswi
 *                dan disembunyikan. Jangan dibuka atau diubah.
 */

var CFG = {
  ZONA: 'Asia/Jakarta',
  MAX_GAGAL: 8,            // salah PIN berturut-turut sebelum dikunci
  KUNCI_MENIT: 15,         // lama akun dikunci
  MAX_SKRINING: 60,        // batas hasil skrining tersimpan per akun
  MAX_BLOB: 45000          // batas ukuran catatan (sel Google Sheet maks 50.000 karakter)
};
var S_AKUN = 'Akun', S_SKRINING = 'Skrining', S_CATATAN = 'Catatan', S_RINGKASAN = 'Ringkasan';
var NAME_RE = /^[\p{L}\p{N}][\p{L}\p{N} .'\-]{1,29}$/u;
var KELAS_RE = /^(?:[\p{L}\p{N}][\p{L}\p{N} .\-\/]{0,19})?$/u;

/* ===================== Persiapan (jalankan sekali) ===================== */

function siapkan() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var akun = buat_(ss, S_AKUN, ['Kunci', 'Nama panggilan', 'Kelas', 'Salt', 'Hash PIN', 'Dibuat', 'Masuk terakhir']);
  var skr = buat_(ss, S_SKRINING, ['Waktu', 'Kunci', 'Nama panggilan', 'Kelas', 'Keluhan (0-8)', 'Faktor risiko (0-6)', 'Tanda bahaya', 'Hasil', 'Kode']);
  var cat = buat_(ss, S_CATATAN, ['Kunci', 'Rev', 'Data terenkripsi', 'Diperbarui']);
  var rin = buat_(ss, S_RINGKASAN, ['Keterangan', 'Jumlah']);

  // kolom kunci harus berformat teks agar nama seperti "123" tidak menjadi angka
  akun.getRange('A:A').setNumberFormat('@');
  cat.getRange('A:A').setNumberFormat('@');
  skr.getRange('B:B').setNumberFormat('@');
  akun.getRange('F:G').setNumberFormat('yyyy-mm-dd hh:mm');
  skr.getRange('A:A').setNumberFormat('yyyy-mm-dd hh:mm');

  // warna baris skrining menurut hasil
  var rng = skr.getRange('A2:I');
  var rules = [
    SpreadsheetApp.newConditionalFormatRule().whenFormulaSatisfied('=$G2="Ya"').setBackground('#F4B6B6').setBold(true).setRanges([rng]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenFormulaSatisfied('=$I2="hi"').setBackground('#FADADD').setRanges([rng]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenFormulaSatisfied('=$I2="mid"').setBackground('#FFF1CC').setRanges([rng]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenFormulaSatisfied('=$I2="lo"').setBackground('#DDF2E8').setRanges([rng]).build()
  ];
  skr.setConditionalFormatRules(rules);
  skr.hideColumns(2);          // kolom Kunci
  skr.hideColumns(9);          // kolom Kode

  // ringkasan otomatis
  if (rin.getLastRow() < 2) {
    rin.getRange(2, 1, 8, 2).setFormulas([
      ['Jumlah akun terdaftar', '=COUNTA(Akun!A2:A)'],
      ['Jumlah hasil skrining tersimpan', '=COUNTA(Skrining!A2:A)'],
      ['Perlu pemeriksaan atau kemungkinan anemia tinggi', '=COUNTIF(Skrining!I2:I,"hi")'],
      ['Ada tanda yang mengarah ke anemia', '=COUNTIF(Skrining!I2:I,"mid")'],
      ['Tanda anemia belum menonjol', '=COUNTIF(Skrining!I2:I,"lo")'],
      ['Hasil skrining dengan tanda bahaya', '=COUNTIF(Skrining!G2:G,"Ya")'],
      ['', ''],
      ['Skrining per kelas', '=QUERY(Skrining!A2:I,"select D, count(B) where D is not null and D <> \'\' group by D label D \'Kelas\', count(B) \'Jumlah\'",0)']
    ]);
  }

  // sembunyikan lembar teknis dan kolom rahasia
  akun.hideColumns(4, 2);      // Salt dan Hash PIN
  cat.hideSheet();

  // hapus lembar kosong bawaan
  var names = ['Sheet1', 'Lembar1'];
  for (var i = 0; i < names.length; i++) {
    var d = ss.getSheetByName(names[i]);
    if (d && d.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(d);
  }
  SpreadsheetApp.flush();
}

function buat_(ss, nama, kepala) {
  var sh = ss.getSheetByName(nama) || ss.insertSheet(nama);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, kepala.length).setValues([kepala]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

/* ===================== Pintu masuk web app ===================== */

function doGet() {
  return ContentService.createTextOutput('SITI NURBAYA API aktif.');
}

function doPost(e) {
  var out;
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
    var req = JSON.parse(e.postData.contents);
    out = tangani_(req);
  } catch (err) {
    console.error(err && err.stack ? err.stack : String(err));
    out = { ok: false, error: 'server' };
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

function tangani_(r) {
  if (!r || typeof r !== 'object') return { ok: false, error: 'input' };
  switch (r.a) {
    case 'register': return daftar_(r);
    case 'login': return masuk_(r);
    case 'save': return simpan_(r);
    case 'skrining': return skrining_(r);
    case 'hapus': return hapus_(r);
  }
  return { ok: false, error: 'input' };
}

/* ===================== Aksi ===================== */

function daftar_(r) {
  var nama = String(r.nama || '').trim().replace(/\s+/g, ' ');
  var kelas = String(r.kelas || '').trim();
  var key = kunci_(nama);
  if (!NAME_RE.test(nama) || !KELAS_RE.test(kelas) || !authValid_(r.auth)) return { ok: false, error: 'input' };
  if (cariAkun_(key)) return { ok: false, error: 'nama_dipakai' };
  var salt = Utilities.getUuid();
  var now = new Date();
  // Buang catatan lama bila petugas pernah menghapus akun ini secara manual.
  var lama = cariCatatan_(key);
  if (lama) lembar_(S_CATATAN).deleteRow(lama.row);
  lembar_(S_AKUN).appendRow([key, nama, kelas, salt, hash_(salt, r.auth), now, '']);
  lembar_(S_CATATAN).appendRow([key, 0, '', now]);
  return { ok: true };
}

function masuk_(r) {
  var c = cek_(r);
  if (c.err) return { ok: false, error: c.err };
  lembar_(S_AKUN).getRange(c.akun.row, 7).setValue(new Date());
  var ct = cariCatatan_(c.key);
  return {
    ok: true,
    nama: String(c.akun.v[1]),
    kelas: String(c.akun.v[2]),
    rev: ct ? Number(ct.v[1]) || 0 : 0,
    blob: ct ? String(ct.v[2] || '') : '',
    skrining: skriningAkun_(c.key)
  };
}

function simpan_(r) {
  var c = cek_(r);
  if (c.err) return { ok: false, error: c.err };
  var blob = String(r.blob || '');
  if (blob.length > CFG.MAX_BLOB) return { ok: false, error: 'data_besar' };
  if (!/^[A-Za-z0-9+\/=]*$/.test(blob)) return { ok: false, error: 'input' };
  var sh = lembar_(S_CATATAN);
  var ct = cariCatatan_(c.key);
  var now = new Date();
  if (!ct) {
    sh.appendRow([c.key, 1, blob, now]);
    return { ok: true, rev: 1 };
  }
  var rev = Number(ct.v[1]) || 0;
  if (Number(r.rev) !== rev) return { ok: false, error: 'konflik', rev: rev, blob: String(ct.v[2] || '') };
  sh.getRange(ct.row, 2, 1, 3).setValues([[rev + 1, blob, now]]);
  return { ok: true, rev: rev + 1 };
}

function skrining_(r) {
  var c = cek_(r);
  if (c.err) return { ok: false, error: c.err };
  var g = Number(r.g), f = Number(r.f), level = String(r.level || '');
  if (!(g === Math.floor(g) && g >= 0 && g <= 8) || !(f === Math.floor(f) && f >= 0 && f <= 6) || ['hi', 'mid', 'lo'].indexOf(level) < 0) {
    return { ok: false, error: 'input' };
  }
  if (skriningAkun_(c.key, 1000).length >= CFG.MAX_SKRINING) return { ok: false, error: 'batas' };
  lembar_(S_SKRINING).appendRow([
    new Date(), c.key, String(c.akun.v[1]), String(c.akun.v[2]), g, f,
    r.b ? 'Ya' : 'Tidak', aman_(String(r.label || '')), level
  ]);
  return { ok: true };
}

function hapus_(r) {
  var c = cek_(r);
  if (c.err) return { ok: false, error: c.err };
  var sk = lembar_(S_SKRINING);
  var n = sk.getLastRow();
  if (n >= 2) {
    var vals = sk.getRange(2, 2, n - 1, 1).getValues();
    for (var i = vals.length - 1; i >= 0; i--) if (String(vals[i][0]) === c.key) sk.deleteRow(i + 2);
  }
  var ct = cariCatatan_(c.key);
  if (ct) lembar_(S_CATATAN).deleteRow(ct.row);
  lembar_(S_AKUN).deleteRow(c.akun.row);
  bersih_(c.key);
  return { ok: true };
}

/* ===================== Pembantu ===================== */

function lembar_(nama) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nama);
  if (!sh) throw new Error('Lembar "' + nama + '" tidak ada. Jalankan fungsi siapkan terlebih dahulu.');
  return sh;
}

function kunci_(nama) {
  return String(nama || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function authValid_(a) {
  return typeof a === 'string' && /^[0-9a-f]{64}$/.test(a);
}

// Mencegah isi sel dibaca sebagai rumus.
function aman_(s) {
  s = String(s).slice(0, 60);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function hash_(salt, auth) {
  var b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + ':' + auth, Utilities.Charset.UTF_8);
  return b.map(function (x) {
    var v = (x < 0 ? x + 256 : x).toString(16);
    return v.length < 2 ? '0' + v : v;
  }).join('');
}

function cariAkun_(key) {
  var sh = lembar_(S_AKUN);
  var n = sh.getLastRow();
  if (n < 2) return null;
  var vals = sh.getRange(2, 1, n - 1, 7).getValues();
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][0]) === key) return { row: i + 2, v: vals[i] };
  }
  return null;
}

function cariCatatan_(key) {
  var sh = lembar_(S_CATATAN);
  var n = sh.getLastRow();
  if (n < 2) return null;
  var vals = sh.getRange(2, 1, n - 1, 4).getValues();
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][0]) === key) return { row: i + 2, v: vals[i] };
  }
  return null;
}

function skriningAkun_(key, maks) {
  var sh = lembar_(S_SKRINING);
  var n = sh.getLastRow();
  var out = [];
  if (n < 2) return out;
  var vals = sh.getRange(2, 1, n - 1, 9).getValues();
  for (var i = vals.length - 1; i >= 0 && out.length < (maks || 20); i--) {
    if (String(vals[i][1]) !== key) continue;
    out.push({
      d: Utilities.formatDate(new Date(vals[i][0]), CFG.ZONA, 'yyyy-MM-dd'),
      g: Number(vals[i][4]), f: Number(vals[i][5]),
      l: String(vals[i][8]), label: String(vals[i][7]), b: vals[i][6] === 'Ya'
    });
  }
  return out;
}

// Memeriksa nama dan PIN. Salah PIN berulang akan mengunci akun sementara.
function cek_(r) {
  var key = kunci_(r.nama);
  if (!key || !authValid_(r.auth)) return { err: 'input' };
  if (terkunci_(key)) return { err: 'terkunci' };
  var a = cariAkun_(key);
  if (!a || hash_(String(a.v[3]), r.auth) !== String(a.v[4])) {
    gagal_(key);
    return { err: 'login_gagal' };
  }
  bersih_(key);
  return { key: key, akun: a };
}

function terkunci_(key) {
  var n = parseInt(CacheService.getScriptCache().get('gagal:' + key) || '0', 10);
  return n >= CFG.MAX_GAGAL;
}

function gagal_(key) {
  var c = CacheService.getScriptCache();
  var n = parseInt(c.get('gagal:' + key) || '0', 10) + 1;
  c.put('gagal:' + key, String(n), CFG.KUNCI_MENIT * 60);
}

function bersih_(key) {
  CacheService.getScriptCache().remove('gagal:' + key);
}
